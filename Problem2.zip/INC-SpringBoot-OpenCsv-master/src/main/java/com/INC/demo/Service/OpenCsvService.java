package com.INC.demo.Service;

import java.io.BufferedReader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.INC.demo.Model.ModelUser;
import com.INC.demo.Repo.RepoOpenCsv;
import com.opencsv.CSVReader;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.HeaderColumnNameTranslateMappingStrategy;

@Service
public class OpenCsvService {
	
	@Autowired
	private RepoOpenCsv repo;
	
	
	public void saveCsv() throws IOException
	{
	        Map<String, String> mapping = new 													
	                      HashMap<String, String>(); 
	        mapping.put("Result Time", "resultTime"); 
	        mapping.put("Granularity Period", "gradualityPeriod"); 
	        mapping.put("ObjectName", "objectName"); 
	        mapping.put("CellID", "cellId"); 
	        mapping.put("CallAttemps", "callAttempts"); 
	  
	        
	        HeaderColumnNameTranslateMappingStrategy<ModelUser> strategy = 
	             new HeaderColumnNameTranslateMappingStrategy<ModelUser>(); 
	        strategy.setType(ModelUser.class); 
	        strategy.setColumnMapping(mapping); 
	  
	        CSVReader csvReader = null; 
	        try { 
	            csvReader = new CSVReader(new FileReader 
	            ("C:\\Users\\Yash\\Desktop\\csv\\FileMain.csv")); 
	        } 
	        catch (FileNotFoundException e) { 
	  
	            e.printStackTrace(); 
	        } 
	        CsvToBean csvToBean = new CsvToBean(); 
	  
	        List<ModelUser> list = csvToBean.parse(strategy, csvReader); 
	  
	        for (ModelUser e : list) { 
	        	repo.save(e);
	            System.out.println(e); 
	        } 
	}

}
