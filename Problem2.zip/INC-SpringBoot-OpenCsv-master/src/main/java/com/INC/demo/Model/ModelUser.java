package com.INC.demo.Model;

import javax.persistence.Entity;

@Entity
public class ModelUser {
	
	@javax.persistence.Id
	private String resultTime;

	private String gradualityPeriod;
	
	private String objectName;
	
	private String cellId;
	
	private String callAttempts;
	
	
	@Override
	public String toString() {
		return "ModelInc [resultTime=" + resultTime + ", gradualityPeriod=" + gradualityPeriod + ", objectName="
				+ objectName + ", cellId=" + cellId + ", callAttempts=" + callAttempts + "]";
	}
	
	
	public String getResultTime() {
		return resultTime;
	}

	public void setResultTime(String resultTime) {
		this.resultTime = resultTime;
	}

	public String getGradualityPeriod() {
		return gradualityPeriod;
	}

	public void setGradualityPeriod(String gradualityPeriod) {
		this.gradualityPeriod = gradualityPeriod;
	}

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public String getCellId() {
		return cellId;
	}

	public void setCellId(String cellId) {
		this.cellId = cellId;
	}

	public String getCallAttempts() {
		return callAttempts;
	}

	public void setCallAttempts(String callAttempts) {
		this.callAttempts = callAttempts;
	}



}
